# Calendario de Vida (Android)

App que dibuja el calendario (Vida, Año o Meta) y lo pone de fondo de pantalla.
Se actualiza sola cada día después de medianoche, sin servidor.

## Compilar sin PC (GitHub Actions)
1. Sube esta carpeta completa a un repositorio de GitHub (incluida `.github/`).
2. Pestaña Actions → "Compilar APK" → espera a que termine.
3. Descarga el artefacto `calendario-de-vida`; dentro está `app-debug.apk`.

## Compilar en PC
Abre la carpeta en Android Studio y pulsa Build → Build APK(s).

## Código
- `Renderer.java`: calcula qué punto es hoy y dibuja la imagen.
- `Updater.java`: pone el fondo y programa la siguiente actualización.
- `UpdateReceiver.java` y `CheckJob.java`: se ejecutan a medianoche, al encender y como respaldo.
- `MainActivity.java`: la pantalla de configuración.
