package mx.calvida;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Respaldo: cada pocas horas revisa si cambió el día, por si la alarma se retrasó. */
public class CheckJob extends JobService {
    @Override
    public boolean onStartJob(final JobParameters params) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Updater.applyIfNeeded(getApplicationContext());
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }
}
