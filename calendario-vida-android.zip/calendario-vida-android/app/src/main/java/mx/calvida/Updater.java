package mx.calvida;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.WallpaperManager;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.util.Calendar;

/** Pone el fondo de pantalla y programa la siguiente actualización. */
final class Updater {
    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
    }

    static int[] screenSize(Context c) {
        DisplayMetrics m = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(m);
        return new int[] {Math.min(m.widthPixels, m.heightPixels), Math.max(m.widthPixels, m.heightPixels)};
    }

    /** Dibuja la imagen de hoy y la pone de fondo. Lanza una excepción si algo falla. */
    static synchronized void apply(Context c) throws Exception {
        SharedPreferences p = prefs(c);
        int[] s = screenSize(c);
        Bitmap bmp = Renderer.render(p, s[0], s[1]);
        int target = p.getInt("target", 0); // 0 = bloqueo, 1 = inicio, 2 = ambas
        int flags = target == 0 ? WallpaperManager.FLAG_LOCK
                : target == 1 ? WallpaperManager.FLAG_SYSTEM
                : WallpaperManager.FLAG_LOCK | WallpaperManager.FLAG_SYSTEM;
        WallpaperManager.getInstance(c).setBitmap(bmp, null, true, flags);
        bmp.recycle();
        p.edit().putLong("lastDay", Renderer.today()).apply();
    }

    /** Solo actualiza si el usuario ya activó la app y el día cambió. */
    static void applyIfNeeded(Context c) {
        SharedPreferences p = prefs(c);
        if (!p.getBoolean("enabled", false)) return;
        if (p.getLong("lastDay", -1) == Renderer.today()) return;
        try {
            apply(c);
        } catch (Exception e) {
            android.util.Log.w("CalVida", "No se pudo actualizar el fondo", e);
        }
    }

    /** Alarma poco después de medianoche + revisión periódica de respaldo. */
    static void schedule(Context c) {
        Calendar next = Calendar.getInstance();
        next.add(Calendar.DAY_OF_MONTH, 1);
        next.set(Calendar.HOUR_OF_DAY, 0);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 30);
        next.set(Calendar.MILLISECOND, 0);
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, new Intent(c, UpdateReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);

        JobInfo job = new JobInfo.Builder(1, new ComponentName(c, CheckJob.class))
                .setPeriodic(3 * 60 * 60 * 1000L)
                .setPersisted(true)
                .build();
        ((JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE)).schedule(job);
    }
}
