package mx.calvida;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

/** Pantalla única: elegir modo y fechas, ver la vista previa y activar el fondo. */
public class MainActivity extends Activity {
    static final String[] MODES = {"life", "year", "goal"};
    static final int[] COLORS = {0xFFFF5A36, 0xFFFFC233, 0xFF4CC38A, 0xFF5B9DFF};

    SharedPreferences prefs;
    ImageView preview;
    TextView status;
    Button birth, start, end, apply;
    LinearLayout swatches;

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = Updater.prefs(this);
        if (!prefs.contains("start")) {
            long t = Renderer.today();
            prefs.edit().putString("start", Renderer.format(t)).putString("end", Renderer.format(t + 100)).apply();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        root.setBackgroundColor(Renderer.BG);

        TextView title = new TextView(this);
        title.setText("Calendario de Vida");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Renderer.PAST);
        root.addView(title);
        root.addView(label("Cada punto es un día o una semana. El punto de color es hoy."));

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(170), LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.topMargin = dp(16);
        root.addView(preview, lp);

        status = label("");
        status.setGravity(Gravity.CENTER);
        root.addView(status);

        root.addView(label("Modo"));
        int mode = java.util.Arrays.asList(MODES).indexOf(prefs.getString("mode", "year"));
        root.addView(radios(new String[] {"Vida", "Año", "Meta"}, mode, new Pick() {
            public void picked(int i) {
                prefs.edit().putString("mode", MODES[i]).apply();
                refresh();
            }
        }));

        birth = dateButton("birth", "Fecha de nacimiento");
        start = dateButton("start", "Inicio de la meta");
        end = dateButton("end", "Fecha objetivo");
        root.addView(birth);
        root.addView(start);
        root.addView(end);

        root.addView(label("Dónde ponerlo"));
        root.addView(radios(new String[] {"Bloqueo", "Inicio", "Ambas"}, prefs.getInt("target", 0), new Pick() {
            public void picked(int i) {
                prefs.edit().putInt("target", i).apply();
            }
        }));

        root.addView(label("Color de hoy"));
        swatches = new LinearLayout(this);
        for (int i = 0; i < COLORS.length; i++) {
            final int color = COLORS[i];
            View v = new View(this);
            v.setContentDescription("Color " + (i + 1));
            v.setOnClickListener(new View.OnClickListener() {
                public void onClick(View x) {
                    prefs.edit().putInt("accent", color).apply();
                    refresh();
                }
            });
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(44), dp(44));
            sp.rightMargin = dp(12);
            swatches.addView(v, sp);
        }
        root.addView(swatches);

        apply = new Button(this);
        apply.setText("Poner fondo y actualizar cada día");
        apply.setAllCaps(false);
        apply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                applyNow();
            }
        });
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ap.topMargin = dp(20);
        root.addView(apply, ap);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Renderer.BG);
        scroll.addView(root);
        setContentView(scroll);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Si la app ya está activada y cambió el día, se pone al corriente al abrirla.
        new Thread(new Runnable() {
            public void run() {
                Updater.applyIfNeeded(getApplicationContext());
            }
        }).start();
    }

    interface Pick {
        void picked(int index);
    }

    TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTextColor(Renderer.TEXT);
        t.setPadding(0, dp(14), 0, dp(4));
        return t;
    }

    RadioGroup radios(String[] names, int checked, final Pick pick) {
        RadioGroup g = new RadioGroup(this);
        g.setOrientation(RadioGroup.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            RadioButton b = new RadioButton(this);
            b.setText(names[i]);
            b.setId(i + 1);
            b.setTextSize(16);
            b.setPadding(0, 0, dp(14), 0);
            g.addView(b);
        }
        g.check(Math.max(0, checked) + 1);
        g.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int id) {
                pick.picked(id - 1);
            }
        });
        return g;
    }

    Button dateButton(final String key, final String name) {
        final Button b = new Button(this);
        b.setAllCaps(false);
        b.setTag(name);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                long d = Renderer.parse(prefs.getString(key, ""));
                int[] ymd = Renderer.ymd(d < 0 ? Renderer.day(1995, 0, 1) : d);
                new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int y, int m, int day) {
                        prefs.edit().putString(key, Renderer.format(Renderer.day(y, m, day))).apply();
                        refresh();
                    }
                }, ymd[0], ymd[1], ymd[2]).show();
            }
        });
        return b;
    }

    void dateText(Button b, String key) {
        String v = prefs.getString(key, "");
        b.setText(b.getTag() + ": " + (v.length() == 0 ? "elegir" : v));
    }

    /** Vuelve a dibujar la vista previa y ajusta qué campos se ven. */
    void refresh() {
        String mode = prefs.getString("mode", "year");
        birth.setVisibility(mode.equals("life") ? View.VISIBLE : View.GONE);
        start.setVisibility(mode.equals("goal") ? View.VISIBLE : View.GONE);
        end.setVisibility(mode.equals("goal") ? View.VISIBLE : View.GONE);
        dateText(birth, "birth");
        dateText(start, "start");
        dateText(end, "end");

        int accent = prefs.getInt("accent", COLORS[0]);
        for (int i = 0; i < COLORS.length; i++) {
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(COLORS[i]);
            if (COLORS[i] == accent) d.setStroke(dp(3), Renderer.PAST);
            swatches.getChildAt(i).setBackground(d);
        }

        try {
            int[] s = Updater.screenSize(this);
            preview.setImageBitmap(Renderer.render(prefs, s[0] / 3, s[1] / 3));
            Renderer.Info info = Renderer.compute(prefs, Renderer.today());
            status.setText("Quedan " + Renderer.summary(info));
            apply.setEnabled(true);
        } catch (IllegalArgumentException e) {
            preview.setImageBitmap(null);
            status.setText(e.getMessage());
            apply.setEnabled(false);
        }
    }

    void applyNow() {
        apply.setEnabled(false);
        status.setText("Poniendo el fondo…");
        new Thread(new Runnable() {
            public void run() {
                String msg;
                try {
                    Updater.apply(getApplicationContext());
                    prefs.edit().putBoolean("enabled", true).apply();
                    Updater.schedule(getApplicationContext());
                    msg = "Listo. Se actualizará solo cada día después de medianoche.";
                } catch (Exception e) {
                    msg = "No se pudo poner el fondo: " + e.getMessage();
                }
                final String text = msg;
                runOnUiThread(new Runnable() {
                    public void run() {
                        status.setText(text);
                        apply.setEnabled(true);
                    }
                });
            }
        }).start();
    }
}
