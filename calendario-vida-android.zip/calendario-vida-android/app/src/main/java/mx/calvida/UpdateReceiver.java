package mx.calvida;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Se ejecuta con la alarma de medianoche, al encender el teléfono o al cambiar la hora. */
public class UpdateReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        final Context app = context.getApplicationContext();
        if (!Updater.prefs(app).getBoolean("enabled", false)) return;
        final PendingResult pending = goAsync();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Updater.applyIfNeeded(app);
                    Updater.schedule(app);
                } finally {
                    pending.finish();
                }
            }
        }).start();
    }
}
