package mx.calvida;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import java.util.Calendar;
import java.util.TimeZone;

/** Calcula qué punto es "hoy" y dibuja el fondo de pantalla. */
final class Renderer {
    static final long DAY = 86400000L;
    static final int BG = 0xFF0B0B0D, PAST = 0xFFE8E6E1, FUTURE = 0xFF2A2A2F, TEXT = 0xFF96948F;

    /** Resultado del cálculo: cuántos puntos hay y cuál es hoy. */
    static final class Info {
        int total, index, cols;
        long left;
        String unit;
    }

    // Las fechas se manejan como "número de día" para evitar líos de zona horaria.
    static long day(int y, int month0, int d) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(y, month0, d);
        return Math.floorDiv(c.getTimeInMillis(), DAY);
    }

    static long today() {
        Calendar c = Calendar.getInstance();
        return day(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
    }

    static int[] ymd(long day) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTimeInMillis(day * DAY);
        return new int[] {c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)};
    }

    /** Convierte "AAAA-MM-DD" en número de día; devuelve -1 si está vacío o mal escrito. */
    static long parse(String s) {
        if (s == null || s.length() != 10) return -1;
        try {
            return day(Integer.parseInt(s.substring(0, 4)), Integer.parseInt(s.substring(5, 7)) - 1,
                    Integer.parseInt(s.substring(8, 10)));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    static String format(long day) {
        int[] d = ymd(day);
        return String.format(java.util.Locale.US, "%04d-%02d-%02d", d[0], d[1] + 1, d[2]);
    }

    static Info compute(SharedPreferences p, long today) {
        Info r = new Info();
        String mode = p.getString("mode", "year");
        if (mode.equals("life")) {
            long birth = parse(p.getString("birth", ""));
            if (birth < 0) throw new IllegalArgumentException("Elige tu fecha de nacimiento.");
            if (birth > today) throw new IllegalArgumentException("La fecha de nacimiento está en el futuro.");
            int[] b = ymd(birth);
            int age = ymd(today)[0] - b[0];
            long last = day(b[0] + age, b[1], b[2]);
            if (last > today) {
                age--;
                last = day(b[0] + age, b[1], b[2]);
            }
            r.total = 90 * 52;
            r.index = age * 52 + (int) Math.min(51, (today - last) / 7);
            r.cols = 52;
            r.left = Math.max(0, r.total - r.index - 1);
            r.unit = "semanas";
        } else if (mode.equals("goal")) {
            long start = parse(p.getString("start", "")), end = parse(p.getString("end", ""));
            if (start < 0 || end < 0) throw new IllegalArgumentException("Elige el inicio y la fecha objetivo.");
            if (end < start) throw new IllegalArgumentException("La fecha objetivo debe ser posterior al inicio.");
            if (end - start + 1 > 20000) throw new IllegalArgumentException("El rango es demasiado largo.");
            r.total = (int) (end - start + 1);
            r.index = (int) Math.max(-1, Math.min(r.total, today - start));
            r.left = Math.max(0, end - today);
            r.unit = "días";
        } else {
            int y = ymd(today)[0];
            long jan1 = day(y, 0, 1);
            r.total = (int) (day(y + 1, 0, 1) - jan1);
            r.index = (int) (today - jan1);
            r.left = r.total - r.index - 1;
            r.unit = "días";
        }
        return r;
    }

    static String summary(Info d) {
        int pct = Math.max(0, Math.min(100, Math.round(d.index * 100f / d.total)));
        return d.left + " " + d.unit + " · " + pct + "%";
    }

    static Bitmap render(SharedPreferences p, int w, int h) {
        Info d = compute(p, today());
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas g = new Canvas(bmp);
        g.drawColor(BG);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Zona de la cuadrícula: arriba queda libre para el reloj, abajo para el texto.
        float ax = w * 0.09f, ay = h * 0.30f, aw = w * 0.82f, ah = h * 0.54f;
        int cols = d.cols;
        float cell = 0;
        if (cols > 0) {
            cell = Math.min(aw / cols, ah / (float) Math.ceil(d.total / (double) cols));
        } else {
            for (int n = 3; n <= 80; n++) { // busca cuántas columnas dan los puntos más grandes
                float s = Math.min(aw / n, ah / (float) Math.ceil(d.total / (double) n));
                if (s > cell) {
                    cell = s;
                    cols = n;
                }
            }
        }
        int rows = (int) Math.ceil(d.total / (double) cols);
        float gx = ax + (aw - cols * cell) / 2, gy = ay + (ah - rows * cell) / 2, r = cell * 0.32f;
        int accent = p.getInt("accent", 0xFFFF5A36);
        for (int i = 0; i < d.total; i++) {
            boolean isToday = i == d.index;
            paint.setColor(isToday ? accent : i < d.index ? PAST : FUTURE);
            g.drawCircle(gx + (i % cols + 0.5f) * cell, gy + (i / cols + 0.5f) * cell,
                    isToday ? Math.min(cell * 0.48f, r * 1.35f) : r, paint);
        }

        paint.setColor(TEXT);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setTextSize(w / 30f);
        paint.setTextAlign(Paint.Align.CENTER);
        g.drawText(summary(d).toUpperCase(new java.util.Locale("es")), w / 2f,
                gy + rows * cell + h * 0.03f + paint.getTextSize(), paint);
        return bmp;
    }
}
